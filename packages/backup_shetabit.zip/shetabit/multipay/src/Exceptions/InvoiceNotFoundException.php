<?php

namespace Shetabit\Multipay\Exceptions;

class InvoiceNotFoundException extends \Exception
{
    //
}
