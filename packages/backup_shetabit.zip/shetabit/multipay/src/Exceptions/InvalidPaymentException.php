<?php

namespace Shetabit\Multipay\Exceptions;

class InvalidPaymentException extends \Exception
{
    //
}
