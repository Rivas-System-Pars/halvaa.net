<?php

namespace Shetabit\Multipay\Exceptions;

class PurchaseFailedException extends \Exception
{
    //
}
